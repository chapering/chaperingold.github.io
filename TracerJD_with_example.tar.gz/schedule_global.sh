#!/bin/bash

VERSION=v0
ROOT=`pwd`
DRIVERCLASS=ScheduleClass
subjectloc=$ROOT/subject/Schedule1/

#JAVA=$ROOT/tools/jdk160/bin/java
JAVA=java
